# Changelog

## [0.1.1](https://github.com/noir-lang/poseidon/compare/v0.1.0...v0.1.1) (2025-05-22)


### Bug Fixes

* Always use u32 when indexing arrays ([#4](https://github.com/noir-lang/poseidon/issues/4)) ([e5fa393](https://github.com/noir-lang/poseidon/commit/e5fa3937f707046f28799243630c9011b08e29d4))

## 0.1.0 (2025-03-11)


### Features

* Initial release ([#1](https://github.com/noir-lang/poseidon/issues/1)) ([e20ea4a](https://github.com/noir-lang/poseidon/commit/e20ea4a7ccd8634a281c09244890b086182611b9))
