---
name: "\U0001F4E6 Circuit"
about: Propose a new ZK-kit Noir circuit
title: ''
labels: 'feature :rocket:'
assignees: ''
---

**Describe the package you'd like**
A clear and concise description of the type of circuit you have in mind.

**Additional context**
Add any other context about the package here.
