---
name: "\u267B Refactoring"
about: Suggest any improvements for this project
title: ''
labels: 'refactoring :recycle:'
assignees: ''
---

**Describe the improvement you're thinking about**
A clear and concise description of what you think could improve the code.

**Describe alternatives you've considered**
A clear and concise description of any alternative solutions you've considered.

**Additional context**
Add any other context or screenshots about the improvement request here.
