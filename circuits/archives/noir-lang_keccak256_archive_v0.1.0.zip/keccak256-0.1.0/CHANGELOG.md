# Changelog

## 0.1.0 (2025-02-12)


### Features

* Initial commit ([d43648b](https://github.com/noir-lang/keccak256/commit/d43648b0f12f0e3de8e8187e05bf0996233ee69d))
