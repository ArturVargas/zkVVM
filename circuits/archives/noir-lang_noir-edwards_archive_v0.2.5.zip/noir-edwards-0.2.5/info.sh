nargo compile --force && bb gates -b ./target/edwards.json
