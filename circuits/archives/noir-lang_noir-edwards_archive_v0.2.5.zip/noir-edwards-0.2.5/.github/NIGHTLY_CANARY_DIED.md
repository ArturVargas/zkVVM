---
title: "Tests fail on latest Nargo nightly release"
assignees: TomAFrench, kashbrti, jtriley-eth
---

The tests on this Noir project have started failing when using the latest nightly release of the Noir compiler. This likely means that there have been breaking changes for which this project needs to be updated to take into account.

Check the [{{env.WORKFLOW_NAME}}]({{env.WORKFLOW_URL}}) workflow for details.
